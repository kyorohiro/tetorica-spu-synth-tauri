// Learning-oriented order for the bundled examples; user folders follow alphabetically.
export const EXAMPLE_FOLDER_ORDER = [
  'basic', 'chip-raw', 'genesis', 'mega-cd', 'game-gear', 'master-system', 'msx', 'gameboy', 'nes', 'c64', 'pc98', 'neogeo', 'x68000', 'dx7', 'snes', 'ps1', 'scsp', 'pc-engine', 'opl',
];
