import {attachPs1TimedClient} from '../js/ps1_timed_client.js';
// SPDX-License-Identifier: BSD-3-Clause
// Copyright (c) 2026, kyorohiro.
import {preparePs1Waveform} from '../js/ps1_waveform.js?v=ps1-cyclic-1';
import {SPU_SYNTH_MIX_HEADROOM} from './spu_synth_levels.js';
import {readMorph, morphPcm} from './spu_synth_morph.js';
import {readPmon, pmonPcm} from './spu_synth_pmon.js';
import {readNoise} from './spu_synth_noise.js';
import {SOUNDCHIP_MIXER_PRESETS} from '../js/soundchip_mixer_presets.js';
import {readSpuInstrument} from './spu_synth_instrument.js?v=spu-split-vab-1';

export const SPU_SYNTH_CALIBRATED_GAIN = SOUNDCHIP_MIXER_PRESETS.calibrated.factoryDefaults.kinds.find(entry => entry.name === 'ps1').volume;
export const SPU_SYNTH_OUTPUT_GAIN = SPU_SYNTH_CALIBRATED_GAIN * SPU_SYNTH_MIX_HEADROOM;
const initialWaveform = () => preparePs1Waveform(Array.from({length:112}, (_, i) => .65 * Math.sin(2 * Math.PI * i / 112)));
const CODE_METHODS=['loadADPCM','getPreset','setPreset','setChannel','setEnvelope','setReverb','setNoiseEnabled','setNoiseClock','setPmonEnabled','setPitch','setFrequency','setNote','keyOn','keyOff','noteOn','noteOff','allNotesOff','reset','getState','snapshot','_setAuditionNoise'];
const READ_METHODS=new Set(['inspect','getState','getEditorState','getPreset','getInstrument','getInstrumentSample','snapshot','findADPCM']);
const codeCancelled=()=>{const error=new Error('SPU Code session stopped');error.name='AbortError';return error;};

/** A standalone Web Audio instrument. Startup creates a suspended context;
 * call resume() from a user gesture before playing. Failed initialization
 * releases the context, so the caller can retry by creating another engine.
 * `command` uses the same identity-safe voice editor operations as Playground.
 * PCM encoding and all DOM work remain on this main thread.
 * @param {{onError?:(error:Error)=>void,onState?:(state:object)=>void,volume?:number}} [options]
 */
export async function createSpuAudio({onError = () => {}, onState = () => {}, volume = 1} = {}) {
  validateVolume(volume);
  const Context = globalThis.AudioContext ?? globalThis.webkitAudioContext;
  if (!Context) throw new Error('This browser does not support Web Audio');
  const context = new Context({latencyHint:'interactive'});
  let node = null, gain = null, codeFade = null, disposed = false, fatalError = null, nextId = 0, rejectReady, readyTimer;
  let codeOwner=null,codeGeneration=0;
  const invalidateCode=()=>{codeGeneration++;codeOwner=null;};
  const pending = new Map();
  let state = null;
  const failPending = error => {for (const {reject,timer} of pending.values()) {clearTimeout(timer);reject(error);} pending.clear();};
  const report = error => {try {onError(error);} catch {}};
  const publish = value => {state = value; try {onState(value);} catch (error) {report(error);}};
  const assertOpen = () => {if (fatalError) throw fatalError; if (disposed || context.state === 'closed') throw new Error('SPU synth is closed');};
  const dispose = async () => {
    if (disposed) return;
    disposed = true;
    invalidateCode();
    clearTimeout(readyTimer);
    context.removeEventListener('statechange', stateChanged);
    failPending(new Error('SPU synth was disposed'));
    if (node) {
      node.onprocessorerror = null;
      node.port.onmessage = null;
      node.port.onmessageerror = null;
      try {node.port.postMessage({method:'dispose'});} catch {}
      node.disconnect();
      node.port.close();
    }
    gain?.disconnect();
    codeFade?.disconnect();
    if (context.state !== 'closed') await context.close();
  };
  const fail = error => {
    if (disposed || fatalError) return;
    fatalError = error;
    rejectReady?.(error);
    failPending(error);
    report(error);
    void dispose().catch(() => {});
  };
  function stateChanged() {if (context.state === 'closed' && !disposed) fail(new Error('SPU synth AudioContext was closed'));}
  context.addEventListener('statechange', stateChanged);

  try {
    // Browsers with unrestricted autoplay can start a new context immediately.
    // Suspend before connecting, keeping page load silent in either policy.
    if (context.state === 'running') await context.suspend();
    if (!context.audioWorklet) throw new Error('SPU synth needs AudioWorklet; open this page over HTTPS or localhost');
    const [wasmBinary] = await Promise.all([
      fetch(new URL('../generated/ps1_spu_wasm.wasm?v=spu-long-audio-1', import.meta.url)).then(response => {
        if (!response.ok) throw new Error(`SPU WASM could not load (HTTP ${response.status})`);
        return response.arrayBuffer();
      }),
      context.audioWorklet.addModule(new URL('./spu_synth_worklet.js?v=spu-code-parameters-6', import.meta.url)),
    ]);
    node = new AudioWorkletNode(context, 'tetorica-spu-synth', {
      numberOfInputs:0, numberOfOutputs:1, outputChannelCount:[2],
      processorOptions:{wasmBinary, initialWaveform:initialWaveform()},
    });
    node.onprocessorerror = () => fail(new Error('SPU synth audio processor failed'));
    node.port.onmessageerror = () => fail(new Error('SPU synth received an unreadable audio reply. Enable audio to restart.'));
    const ready = new Promise((resolve, reject) => {
      rejectReady = reject;
      readyTimer = setTimeout(() => fail(new Error('SPU synth audio initialization timed out')), 15000);
      node.port.onmessage = ({data}) => {
        if (data?.fatal) {fail(new Error(data.error ?? 'SPU synth audio processor failed')); return;}
        if (data?.ready) {clearTimeout(readyTimer); resolve(data); return;}
        const request = pending.get(data?.id);
        if (!request) return;
        pending.delete(data.id);clearTimeout(request.timer);
        if (data.error) {
          const error = new Error(data.error); error.name = data.name ?? 'Error'; request.reject(error);
        } else {
          if (data.state&&request.canPublish()) publish(data.state);
          request.resolve(data.value);
        }
      };
    });
    const metadata = await ready;
    assertOpen();
    gain = context.createGain();
    gain.gain.value = volume * SPU_SYNTH_OUTPUT_GAIN;
    codeFade = context.createGain();codeFade.gain.value=1;
    node.connect(codeFade);codeFade.connect(gain);
    gain.connect(context.destination);
    publish(metadata.state);
    const request = (method, args = [], transfer = []) => {
      assertOpen();
      const id = ++nextId;
      const owner=['editInstrument','applyInstrument','setInstrumentSample'].includes(method)?codeOwner:null;
      return new Promise((resolve, reject) => {
        const timer=setTimeout(()=>fail(new Error(`SPU synth command timed out (${method}). Enable audio to restart.`)),15000);
        pending.set(id, {resolve, reject,timer,canPublish:()=>!owner||codeOwner===owner&&owner.generation===codeGeneration});
        try {node.port.postMessage({id, method, args}, transfer);} catch (error) {pending.delete(id);clearTimeout(timer);reject(error);}
      });
    };
    async function command(method,args=[]) {
      if (!Array.isArray(args)) throw new TypeError('SPU command arguments must be an array');
      if(!['beginCode','code','codeTimed','observeCode','setClickGuard','applyInstrument','editInstrument','setInstrumentSample','instrumentNoteOn','instrumentNoteOff','instrumentAllNotesOff','setInstrumentPitchBend'].includes(method)&&!READ_METHODS.has(method))invalidateCode();
      else if(!codeOwner&&['applyInstrument','setInstrumentSample','instrumentNoteOn','instrumentNoteOff','instrumentAllNotesOff','setInstrumentPitchBend'].includes(method))invalidateCode();
      const editing=method==='editInstrument',editOwner=codeOwner;let editSession,editTarget,editMethod;
      if(editing){
        [editSession,editTarget,editMethod,args]=args;
        if(!Number.isSafeInteger(editSession)||editSession!==codeOwner?.session)throw codeCancelled();
        if(!Array.isArray(args))throw new TypeError('SPU editor arguments must be an array');method=editMethod;
      }
      // The encoder must not run in the real-time audio processor.
      if(method==='applyInstrument') {
        const session=args.length>1?args[1]:codeOwner?.session??null;
        if(session!==null&&!Number.isSafeInteger(session)||session!==(codeOwner?.session??null))throw codeCancelled();
        const instrument=readSpuInstrument(args[0]);
        args=[{preset:instrument.preset,reverb:instrument.reverb,pmon:instrument.pmon,noise:instrument.noise,morph:instrument.morph,
          sample:instrument.version===1?instrument.sample:null,hostAudio:instrument.version===2?instrument.sample:null,
          waveform:instrument.waveform?preparePs1Waveform(instrument.waveform):null,
          pmonWaveform:instrument.pmon.enabled?preparePs1Waveform(pmonPcm(instrument.pmon.depth,instrument.pmon.waveform)):null,
          noiseWaveform:instrument.noise.enabled?preparePs1Waveform(Array(112).fill(0)):null},session];
      }
      else if (method === 'setWaveform') args = [args[0], preparePs1Waveform(args[1]), args[2]];
      else if (method === 'setInstrumentWaveform') args = [preparePs1Waveform(args[0]), args[1]];
      else if (method === 'setInstrumentMorph') {
        const settings=readMorph(args[0]);
        args=[settings,settings.enabled ? preparePs1Waveform(morphPcm(settings)) : undefined,args[1]];
      }
      else if (method === 'setInstrumentPmon') {
        const settings=readPmon(args[0]);
        const needsWaveform=settings.enabled && (editing||!state?.pmonSampleReserved || !state?.pmon?.enabled || settings.depth!==state.pmon.depth || settings.waveform!==state.pmon.waveform);
        args=[settings, needsWaveform ? preparePs1Waveform(pmonPcm(settings.depth,settings.waveform)) : undefined,args[1]];
      }
      else if(editing&&method==='setInstrumentNoise')args=[readNoise(args[0]),args[1],preparePs1Waveform(Array(112).fill(0))];
      if(editing){const value=await request('editInstrument',[editSession,editTarget,editMethod,args]);if(codeOwner!==editOwner||editOwner.generation!==codeGeneration){const error=codeCancelled();error.committed=true;throw error;}return value;}
      return request(method,args,method==='loadHostPCM'?[args[0].buffer]:[]);
    }
    function getPs1Client() {
      assertOpen();if(codeOwner)return codeOwner.promise;
      const owner={generation:codeGeneration,promise:null};codeOwner=owner;
      const check=()=>{assertOpen();if(codeOwner!==owner||owner.generation!==codeGeneration)throw codeCancelled();};
      owner.promise=command('beginCode').then(metadata=>{
        check();if(!Number.isSafeInteger(metadata?.session)||metadata.nativeSampleRate!==44100||metadata.channelCount!==24)throw new Error('Invalid SPU Code session');
        owner.session=metadata.session;
        const client={id:'ps1:synth',chip:'ps1',channelCount:24,nativeSampleRate:44100,sampleRate:context.sampleRate};
        for(const method of CODE_METHODS)client[method]=(...args)=>{
          check();
          if(['getPreset','setPreset','setChannel','setEnvelope','setNoiseEnabled','setNoiseClock','setPmonEnabled','setPitch','setFrequency','setNote','keyOn','keyOff','noteOn','noteOff'].includes(method)&&
            (!Number.isInteger(args[0])||args[0]<0||args[0]>23))throw new RangeError('PS1 SPU channel must be 0..23');
          return command('code',[metadata.session,method,args]).then(value=>{check();return value;});
        };
        // A temporary performer may borrow the existing Code output gate.
        // After its own acknowledged Stop it may reopen only the neutral
        // route it restored, never a newer Code lease or editor operation.
        let releasedGeneration=null;
        client.ownsOutput=()=>{
          try {assertOpen();}catch{return false;}
          return codeOwner===owner&&owner.generation===codeGeneration ||
            releasedGeneration!==null&&codeOwner===null&&codeGeneration===releasedGeneration;
        };
        // The borrowed chip and context belong to the editor, not user Code.
        client.dispose=()=>{
          check();const pending=command('stop'),generation=codeGeneration;
          return pending.then(value=>{releasedGeneration=generation;return value;});
        };
        client.isCurrent=()=>{try{check();return true;}catch{return false;}};
        client._requestControl=(_method,args)=>{check();return command('codeTimed',[metadata.session,args[0]]).then(value=>{check();return value;});};
        return attachPs1TimedClient(client,{instanceId:metadata.instanceId},node.port);
      }).catch(error=>{if(codeOwner===owner)codeOwner=null;throw error;});
      return owner.promise;
    }
    return {
      context, node, gain, calibratedGain:SPU_SYNTH_CALIBRATED_GAIN,
      codeInputNode:node,codeOutputNode:codeFade,codeFadeNode:codeFade,getPs1Client,
      get codeSession(){return codeOwner?.session??null;},
      get state() {return state;},
      async inspect() {const value = await request(codeOwner?'getEditorState':'inspect'); if(!codeOwner)publish(value); return value;},
      command,
      async resume() {assertOpen(); await context.resume(); assertOpen();},
      stop() {return command('stop');},
      setVolume(value) {
        assertOpen(); validateVolume(value); volume = value;
        const parameter = gain.gain, now = context.currentTime;
        // Cancel a previous ramp at its actual current value to keep gestures
        // smooth even when a user moves the slider before a ramp finishes.
        if (typeof parameter.cancelAndHoldAtTime === 'function') parameter.cancelAndHoldAtTime(now);
        else {const current = parameter.value; parameter.cancelScheduledValues(now); parameter.setValueAtTime(current, now);}
        parameter.linearRampToValueAtTime(value * SPU_SYNTH_OUTPUT_GAIN, now + .01);
      },
      dispose,
    };
  } catch (error) {
    await dispose().catch(() => {});
    throw error;
  } finally {clearTimeout(readyTimer);}
}

function validateVolume(value) {if (!Number.isFinite(value) || value < 0 || value > 3.8) throw new RangeError('SPU volume must be from 0 to 3.8');}
